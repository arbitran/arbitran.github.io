<?php

$method = $_SERVER['REQUEST_METHOD'];
$server = $_SERVER['HTTP_HOST'];
$ip = $_SERVER['REMOTE_ADDR'];
//Script Foreach
$c = true;
if ( $method === 'POST' ) {

	$project_name = "Сообщение";
	$admin_email  = "bussines.manag@gmail.com"; // кому 
	$form_subject = "Заказ";
    $date=date("d.m.y"); 
    $time=date("H:i");


	foreach ( $_POST as $key => $value ) {
		if ( $value != "" && $key != "project_name" && $key != "admin_email" && $key != "form_subject" ) {
			$message .= "
			" . ( ($c = !$c) ? '<tr>':'<tr style="background-color: #f8f8f8;">' ) . "
				<td style='padding: 10px; border: #e9e9e9 1px solid;'><b>$key</b></td>
				<td style='padding: 10px; border: #e9e9e9 1px solid;'>$value</td>
			</tr>
			";
		}
	}
} else if ( $method === 'GET' ) {

	$project_name = trim($_GET["project_name"]);
	$admin_email  = trim($_GET["admin_email"]);  
	$form_subject = trim($_GET["form_subject"]);

	foreach ( $_GET as $key => $value ) {
		if ( $value != "" && $key != "project_name" && $key != "admin_email" && $key != "form_subject" ) {
			$message .= "
			" . ( ($c = !$c) ? '<tr>':'<tr style="background-color: #f8f8f8;">' ) . "
				<td style='padding: 10px; border: #e9e9e9 1px solid;'><b>$key</b></td>
				<td style='padding: 10px; border: #e9e9e9 1px solid;'>$value</td>
			</tr>
			";
		}
	}
}

$message = "<table style='width: 100%;'>$message <td style='background-color: #EDFCF0;padding: 10px; border: #e9e9e9 1px solid;'><b>Время заказа</b> </td><td style='background-color: #EDFCF0;padding: 10px; border: #e9e9e9 1px solid;'> $date  $time</td>
<tr><td style='background-color: #EDFCF0;padding: 10px; border: #e9e9e9 1px solid;'><strong>IP отправителя</strong></td>
<td style='background-color: #EDFCF0;padding: 10px; border: #e9e9e9 1px solid;'><a href='http://ipgeobase.ru/?address=$ip'>$ip</a></td></tr>
</table>";

function adopt($text) {
	return '=?UTF-8?B?'.Base64_encode($text).'?=';
}

$headers = "MIME-Version: 1.0" . PHP_EOL .
"Content-Type: text/html; charset=utf-8" . PHP_EOL .
'From: '.adopt($project_name).' <'."informer@$server".'>' . PHP_EOL . 
'Reply-To: '."informer@$server".'' . PHP_EOL;                         
if (mail($admin_email, adopt($form_subject), $message, $headers ));
else echo 'Oshibka otpravki - otklyuchena funkciya (php mail). Obratites v podderzhku xostinga';
?>